<?php
/*
Plugin Name: SEO Manage
Description: Managing Seo

*/



?>